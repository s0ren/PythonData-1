#!/usr/bin/env python3

def find_matching(L, pattern):
    return []

def main():
    pass

if __name__ == "__main__":
    main()
