#!/usr/bin/env python3

def positive_list(L):
    return []

def main():
    pass

if __name__ == "__main__":
    main()
