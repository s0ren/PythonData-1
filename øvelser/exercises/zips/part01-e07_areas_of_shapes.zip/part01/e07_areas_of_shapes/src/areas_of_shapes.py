#!/usr/bin/env python3

import math


def main():
    # enter you solution here

if __name__ == "__main__":
    main()
