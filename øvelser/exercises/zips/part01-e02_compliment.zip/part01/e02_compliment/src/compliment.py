#!/usr/bin/env python3


def main():
    # Enter you solution here


if __name__ == "__main__":
    main()
