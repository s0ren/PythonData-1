#!/usr/bin/env python3

def reverse_dictionary(d):
    return {}

def main():
    pass

if __name__ == "__main__":
    main()
