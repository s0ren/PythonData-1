#!/usr/bin/env python3

def regression():
    return "hello"

def main():
    print(regression())

if __name__ == "__main__":
    main()
