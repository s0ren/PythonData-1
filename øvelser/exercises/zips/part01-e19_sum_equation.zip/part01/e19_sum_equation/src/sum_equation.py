#!/usr/bin/env python3

def sum_equation(L):
    return ""

def main():
    pass

if __name__ == "__main__":
    main()
