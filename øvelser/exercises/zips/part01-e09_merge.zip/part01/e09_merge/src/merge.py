#!/usr/bin/env python3

def merge(L1, L2):
    return []

def main():
    pass

if __name__ == "__main__":
    main()
