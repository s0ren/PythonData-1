#!/usr/bin/env python3

def transform(s1, s2):
    return []

def main():
    pass

if __name__ == "__main__":
    main()
